public interface IHangmanController {

  void play();

}
